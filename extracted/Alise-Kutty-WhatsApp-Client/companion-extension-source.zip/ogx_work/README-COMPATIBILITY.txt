OGxISAI MIC — CROSS-BROWSER PACKAGE
Version: 1.2.0

WHAT THIS PACKAGE TARGETS
- Chromium desktop browsers that support Manifest V3 extensions: Google Chrome, Microsoft Edge, Brave, Opera, Vivaldi and other compatible Chromium browsers.
- Firefox desktop: Manifest V3 package includes a Gecko extension ID and minimum-version declaration.
- Android: Kiwi Browser may load Chromium extensions. Firefox for Android support depends on the browser's add-on installation rules and extension compatibility.

IMPORTANT LIMITATIONS
- No single browser-extension ZIP can run in literally every browser.
- Google Chrome on Android does not support ordinary desktop Chrome extensions.
- Samsung Internet does not provide general support for loading arbitrary Chrome extensions.
- Safari requires a separately packaged Safari Web Extension (typically built/signable through Apple's tooling); this ZIP is not a Safari package.
- Native WhatsApp, Instagram and ShareChat Android/iOS app calls are outside a browser extension's reach. The extension can only run on supported browser pages.
- WhatsApp/Discord may change their call internals. A matching URL and successful installation do not guarantee that microphone effects are transmitted to the other participant. Test with a second account/device and normal consent.

INSTALLATION
Chromium desktop: open the browser's Extensions page, enable Developer mode, choose Load unpacked, and select the extracted folder. For browsers that accept packaged extensions, follow their own extension installation flow.
Firefox desktop: use Firefox's Add-ons debugging/temporary installation for testing, or sign/package the extension for normal distribution.

SUPPORTED SITE TARGETS
- https://web.whatsapp.com/*
- https://discord.com/*
- https://ptb.discord.com/*
- https://canary.discord.com/*
- https://www.instagram.com/* and Instagram subdomains
- https://sharechat.com/* and ShareChat subdomains

This package widens browser-family compatibility metadata; it does not claim verified call-audio compatibility on every browser/device.


CROSS-SITE AUDIO LIMITATION
The extension UI and microphone-processing hook are enabled on the added
Instagram and ShareChat web domains. This does not guarantee that processed
audio reaches another person in every site's call feature. That depends on
the site's current WebRTC/microphone implementation and browser restrictions.
If a site does not expose a browser-based call using the standard microphone
API, an extension cannot add that call capability.

BROWSER LIMITATION
This is a cross-browser-oriented WebExtension package, not a universal
extension for literally every browser. Chromium and Firefox compatibility
depends on each browser's current Manifest V3 support and extension policies.
Safari needs a separately packaged Safari Web Extension. Chrome for Android
does not support ordinary desktop Chrome extensions; Android browsers vary.
