package com.alisekutty.client

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.webkit.CookieManager
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.json.JSONObject
import java.io.File
import java.util.zip.ZipInputStream

class MainActivity : Activity() {
    private lateinit var web: WebView
    private lateinit var status: TextView
    private val pickZip = 4102
    private val micRequest = 4103
    private var pendingWebPermission: PermissionRequest? = null
    private val extensionsDir by lazy { File(filesDir, "extensions").apply { mkdirs() } }
    private val gold = Color.rgb(212, 175, 55)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        CookieManager.getInstance().setAcceptCookie(true)
        buildScreen()
        web.loadUrl("https://web.whatsapp.com/")
    }


    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(8, 8, 8))
        }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            setPadding(14, 8, 14, 8)
            setBackgroundColor(Color.BLACK)
        }
        val title = TextView(this).apply {
            text = "Alise×Kutty  ◆"
            textSize = 19f
            setTextColor(gold)
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        }
        val ext = Button(this).apply {
            text = "OGxISAI / Extensions"
            setTextColor(Color.BLACK)
            setBackgroundColor(gold)
            setOnClickListener { showExtensions() }
        }
        bar.addView(title); bar.addView(ext)
        status = TextView(this).apply {
            text = "BLACK & GOLD  •  WhatsApp Web + OGxISAI mic panel"
            textSize = 11f
            setTextColor(gold)
            setPadding(12, 7, 12, 7)
            setBackgroundColor(Color.rgb(25, 22, 12))
        }
        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.databaseEnabled = true
            settings.loadsImagesAutomatically = true
            settings.mediaPlaybackRequiresUserGesture = false
            settings.userAgentString = "Mozilla/5.0 (Linux; Android 13; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
            CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
            webChromeClient = object : WebChromeClient() {
                override fun onPermissionRequest(request: PermissionRequest) {
                    runOnUiThread {
                        val wantsAudio = request.resources.contains(PermissionRequest.RESOURCE_AUDIO_CAPTURE)
                        if (wantsAudio && ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                            pendingWebPermission = request
                            ActivityCompat.requestPermissions(this@MainActivity, arrayOf(Manifest.permission.RECORD_AUDIO), micRequest)
                        } else {
                            val allowed = request.resources.filter { it == PermissionRequest.RESOURCE_AUDIO_CAPTURE }
                            if (allowed.isNotEmpty()) request.grant(allowed.toTypedArray()) else request.deny()
                        }
                    }
                }
            }
            webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView?, url: String?) {
                    super.onPageFinished(view, url)
                    if (url?.startsWith("https://web.whatsapp.com") == true) {
                        applyEnabledStyles()
                        injectOgxIsai()
                    }
                }
                override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean {
                    return !(url.startsWith("https://web.whatsapp.com") || url.startsWith("https://www.whatsapp.com"))
                }
            }
        }
        root.addView(bar); root.addView(status)
        root.addView(web, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun injectOgxIsai() {
        // Runs the user's OGxISAI injector in the WhatsApp Web page context.
        // WhatsApp may change its WebRTC internals; end-to-end call routing is not guaranteed.
        val js = assets.open("ogxisai/injector.js").bufferedReader().use { it.readText() }
        val encoded = android.util.Base64.encodeToString(js.toByteArray(Charsets.UTF_8), android.util.Base64.NO_WRAP)
        val loading = "file:///android_asset/ogxisai/loading.gif"
        val header = "file:///android_asset/ogxisai/header.gif"
        val wrapper = "(function(){var old=document.getElementById('ogxisai-asset-marker');if(old)return;var m=document.createElement('script');m.id='ogxisai-asset-marker';m.dataset.loadingGif='$loading';m.dataset.headerGif='$header';(document.head||document.documentElement).appendChild(m);var code=atob('$encoded');(0,Function)(code)();})();"
        web.evaluateJavascript(wrapper, null)
    }

    private fun showExtensions() {
        val items = arrayOf("Open OGxISAI microphone panel (on WhatsApp Web)", "Import CSS theme ZIP", "About compatibility")
        AlertDialog.Builder(this).setTitle("Alise×Kutty • Black & Gold")
            .setItems(items) { _, which -> when (which) {
                0 -> { injectOgxIsai(); Toast.makeText(this, "OGxISAI injection requested. Open a WhatsApp Web call to test.", Toast.LENGTH_LONG).show() }
                1 -> openZipPicker()
                2 -> AlertDialog.Builder(this).setTitle("Compatibility")
                    .setMessage("OGxISAI is a browser extension. This build embeds its injector into WhatsApp Web and requests microphone permission. It cannot modify calls in the native WhatsApp app. Whether processed audio reaches the other caller depends on WhatsApp Web and Android WebView support; test with a second device. Instagram and ShareChat extension targets are not included in this WhatsApp-only WebView.")
                    .setPositiveButton("OK", null).show()
            } }.setNegativeButton("Close", null).show()
    }

    private fun openZipPicker() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "application/zip"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/zip", "application/x-zip-compressed", "application/octet-stream"))
        }
        startActivityForResult(intent, pickZip)
    }

    @Deprecated("Deprecated by Android, retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == pickZip && resultCode == Activity.RESULT_OK) {
            val uri = data?.data ?: return
            try { importCssZip(uri); Toast.makeText(this, "CSS theme imported", Toast.LENGTH_LONG).show(); applyEnabledStyles() }
            catch (e: Exception) { Toast.makeText(this, "Import failed: ${e.message}", Toast.LENGTH_LONG).show() }
        }
    }

    private fun importCssZip(uri: Uri) {
        val id = "ext_${System.currentTimeMillis()}"; val target = File(extensionsDir, id).apply { mkdirs() }
        var manifestFound = false; var cssFound = false
        contentResolver.openInputStream(uri).use { raw ->
            requireNotNull(raw) { "Cannot open ZIP" }
            ZipInputStream(raw).use { zip ->
                var entry = zip.nextEntry
                while (entry != null) {
                    if (!entry.isDirectory) {
                        val name = entry.name.substringAfterLast('/')
                        require(name == "manifest.json" || name == "style.css") { "Only manifest.json and style.css are accepted" }
                        val bytes = zip.readBytes(); require(bytes.size <= 512 * 1024) { "Extension file too large" }
                        File(target, name).writeBytes(bytes)
                        if (name == "manifest.json") manifestFound = true
                        if (name == "style.css") cssFound = true
                    }
                    zip.closeEntry(); entry = zip.nextEntry
                }
            }
        }
        require(manifestFound && cssFound) { "ZIP must contain manifest.json and style.css" }
        val manifest = JSONObject(File(target, "manifest.json").readText())
        require(manifest.optString("entry") == "style.css") { "manifest entry must be style.css" }
        if (manifest.optString("name").isBlank()) manifest.put("name", id)
        File(target, "manifest.json").writeText(manifest.toString(2)); File(target, "enabled.flag").writeText("enabled")
    }

    private fun applyEnabledStyles() {
        val css = extensionsDir.listFiles()?.filter { it.isDirectory && File(it, "enabled.flag").exists() }
            ?.mapNotNull { dir -> runCatching { File(dir, "style.css").readText() }.getOrNull() }?.joinToString("\n") ?: ""
        val encoded = android.util.Base64.encodeToString(css.toByteArray(Charsets.UTF_8), android.util.Base64.NO_WRAP)
        web.evaluateJavascript("(function(){var c=atob('$encoded');var s=document.getElementById('alisekutty-extension-css');if(!s){s=document.createElement('style');s.id='alisekutty-extension-css';document.head.appendChild(s);}s.textContent=c;})();", null)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == micRequest) {
            val request = pendingWebPermission; pendingWebPermission = null
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED && request != null) {
                val allowed = request.resources.filter { it == PermissionRequest.RESOURCE_AUDIO_CAPTURE }
                if (allowed.isNotEmpty()) request.grant(allowed.toTypedArray()) else request.deny()
            } else request?.deny()
        }
    }

    override fun onBackPressed() { if (::web.isInitialized && web.canGoBack()) web.goBack() else super.onBackPressed() }
    override fun onDestroy() { if (::web.isInitialized) web.destroy(); super.onDestroy() }
}
