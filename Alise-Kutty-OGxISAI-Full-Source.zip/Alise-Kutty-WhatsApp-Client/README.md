# Alise×Kutty — Black & Gold + OGxISAI

Unofficial Android WebView client for WhatsApp Web. It embeds the supplied OGxISAI `injector.js` into the WhatsApp Web page and requests Android microphone permission when the page asks for audio capture.

## Build APK
1. Open this folder in Android Studio (JDK 17, Android SDK platform 35).
2. Allow Gradle sync.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. APK: `app/build/outputs/apk/debug/app-debug.apk`.

Or push to GitHub and run **Actions → Alise Kutty APK Build**. Download the `Alise-Kutty-APK` artifact.

## OGxISAI limitations
- The supplied Chrome/Firefox extension is not a native Android app. This project embeds its page injector in the WhatsApp Web WebView instead of installing the browser extension.
- Microphone permission is requested at runtime. Use the OGxISAI panel only after allowing permission.
- This does not affect calls in the official WhatsApp Android app. It only targets WhatsApp Web in this app.
- WhatsApp Web may change its WebRTC implementation; Android WebView may restrict audio-track replacement. Therefore processed voice reaching the other caller is **not guaranteed**. Test a call with a second device and obtain the other participant's consent.
- Instagram and ShareChat targets from the extension are not wired into this WhatsApp-only WebView.
- Only import CSS theme ZIPs through the in-app theme importer; the OGxISAI JavaScript is bundled as app assets and is not treated as a user-importable theme.

This is an unofficial third-party client and is not affiliated with or endorsed by WhatsApp/Meta. Never share your WhatsApp verification code or QR login with anyone.
